const request = require('request-promise');
const aws = require("aws-sdk");
const sns = new aws.SNS();

const priceAlert = 2500;

const options = {
    'method': 'GET',
    'url': 'https://data-asg.goldprice.org/dbXRates/EUR',
    resolveWithFullResponse: true
};

function check_gold_price() {
    return request(options);
}

function send_message(price) {
    const snsParams = {
        TopicArn: process.env.SNS_TOPIC_ARN,
        Subject: "Gold price",
        Message: `Hey, the price of gold is ${price}`
    };
    let response = sns.publish(snsParams).promise();

    response.then(function () {
        console.log('Message has been send');
    }).catch(function (err) {
        console.error(err, err.stack);
    });
}

exports.handler = () => {
    check_gold_price().then(response => {
        if (response.statusCode === 200 && response.body) {
            let json = JSON.parse(response.body);
            let price = json.items[0]?.xauPrice;
            if (price < priceAlert) {
                send_message(price);
            }
        }
    });
};

exports.handler();